# Responsive Vertical Timeline

An easy to customize, responsive timeline.

[Article on CodyHouse](https://codyhouse.co/gem/vertical-timeline)

[Demo](https://codyhouse.co/demo/vertical-timeline)
 
[License](https://codyhouse.co/license)

## Dependencies

This experiment is built upon the [CodyHouse Framework](https://github.com/CodyHouse/codyhouse-framework).

## Credits

Icons: [Nucleo Library](https://nucleoapp.com/)
